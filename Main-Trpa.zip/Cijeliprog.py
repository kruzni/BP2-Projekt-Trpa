import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox 
import tkinter as tk
# import CrudeBolnica
# import CrudeBolnicaObicanZaposlenik
# import CrudeZaposlenik
# import CrudeBolnicaZaposlenikSaOvlastima
# import CrudeDarivateljObicanZaposlenik
# import CrudeDarivateljZaposlenikSaOvlastima
# import CrudePrijevoznikObicanZaposlenik
# import CrudePrijevoznikZaposlenikSaOvlastima
# import CrudeZaposlenikObicanZaposlenik
# import CrudeZaposlenikZaposlenikSaOvlastima
import DarivateljCrude
# import PrijevoznikCrude

root = Tk()
root.title("Banka krvi")
root.geometry("1800x900")
root.iconbitmap("krv.ico")
my_tree = ttk.Treeview(root)
root['bg'] = '#9E5D5D'

def uf():
    w2=Toplevel()
    w2.title("Sustav Banke krvi")
    w2.geometry("600x600")
    w2.iconbitmap('krv.ico')
    w2['bg'] = '#9E5D5D'
class Login(tk.Tk):
        def __init__(self):
            tk.Tk.__init__(self)
            self.title("Prijava")
            self.geometry("600x600")
            self.label1 = tk.Label(self, text="ID:")
            self.label1.pack()
            self.entry1 = tk.Entry(self)
            self.entry1.pack()
            self.button = tk.Button(self, text="Log in", command=self.login)
            self.button.pack()
def login(self):
        id = self.entry1.get()
        #connect to the database
        conn=pymysql.connect(host='localhost',user='root',password='root',database="baza_banke_krvi")
        cur = conn.cursor()
        cur.execute("SELECT id FROM zaposlenik WHERE id = %s", (id))
        result = cur.fetchone()
        if result:
            if result[0]:
                if id == '1':
                    role = 'admin'
                elif int(id) >= 2 and int(id) <= 10:
                    role = 'special_authorities'
                elif int(id) >= 11 and int(id) <= 30:
                    role = 'regular_worker'
                else:
                    self.label3 = tk.Label(self, text="Invalid ID number")
                    self.label3.pack()
                    return
                if role == "admin":
                    darivatelj_w = Toplevel()
                    darivatelj_w.title('Darivatelji')
                    darivatelj_w.geometry('1920x1080')
                    darivatelj_txt = darivatelj_create_txt = Label(darivatelj_w, text = 'Podaci o darivatelju').pack()
                    darivatelj_create_button = Button(darivatelj_w, text = 'Darivatelj CRUD', command=lambda:DarivateljCrude.DarivateljCrude(), fg = 'white', bg='blue', padx=15, pady=15, font='sans-serif').pack()




                elif role == "Zaposlenik s više ovlasti":
                    self.destroy()
                    self.main_program = MainProgramSpecialAuthorities()
                elif role == "Običan zaposlenik":
                    self.destroy()
                    self.main_program = MainProgramRegularWorker()

root.mainloop()