import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox 
import tkinter as tk
import CrudeBolnica
import CrudeBolnicaObicanZaposlenik
import CrudeZaposlenik
import CrudeBolnicaZaposlenikSaOvlastima
import CrudeDarivateljObicanZaposlenik
import CrudeDarivateljZaposlenikSaOvlastima
import CrudePrijevoznikObicanZaposlenik
import CrudePrijevoznikZaposlenikSaOvlastima
import CrudeZaposlenikObicanZaposlenik
import CrudeZaposlenikZaposlenikSaOvlastima
import DarivateljCrude
import PrijevoznikCrude


def connection(): 
            conn=pymysql.connect(host='localhost',user='root',password='root',database="baza_banke_krvi")
            return conn

def refreshTable():
            for data in my_tree.get_children():
                my_tree.delete(data)
                
            for array in read():
                my_tree.insert(parent='',index='end',iid=array,text="",values=(array),tag="orow")
                
            my_tree.tag_configure('orow',background='#EEEEEE',font=('Arial',9))
            my_tree.grid(row=12,column=0,columnspan=5,rowspan=11,padx=10,pady=20)


root = Tk()
root.title("Banka krvi")
root.geometry("1800x900")
root.iconbitmap("krv.ico")
my_tree = ttk.Treeview(root)
root['bg'] = '#9E5D5D'
#rezervirana mjesta za upis
rezmj1=tk.StringVar()
rezmj2=tk.StringVar()
rezmj3=tk.StringVar()
rezmj4=tk.StringVar()
rezmj5=tk.StringVar()
rezmj6=tk.StringVar()
rezmj7=tk.StringVar()
rezmj8=tk.StringVar()
rezmj9=tk.StringVar()

#postavljanje vrijednosti za rez mjesta

def postRezMj(rijec, broj):
    if broj == 1:
        rezmj1.set(rijec)
    if broj == 2:
        rezmj2.set(rijec)
    if broj == 3:
        rezmj3.set(rijec)
    if broj == 4:
        rezmj4.set(rijec)
    if broj == 5:
        rezmj5.set(rijec)
    if broj == 6:
        rezmj6.set(rijec)
    if broj == 7:
        rezmj7.set(rijec)
    if broj == 8:
        rezmj8.set(rijec)
    if broj == 9:
        rezmj9.set(rijec)



class Login(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.title("Prijava")
        self.geometry("600x600")
        self.label1 = tk.Label(self, text="ID:")
        self.label1.pack()
        self.entry1 = tk.Entry(self)
        self.entry1.pack()
        self.button = tk.Button(self, text="Log in", command=self.login)
        self.button.pack()

    def login(self):
        id = self.entry1.get()
        #connect to the database
        conn=pymysql.connect(host='localhost',user='root',password='root',database="baza_banke_krvi")
        cur = conn.cursor()
        cur.execute("SELECT id FROM zaposlenik WHERE id = %s", (id))
        result = cur.fetchone()
        if result:
            if result[0] == password:
                if id_number == '1':
                    role = 'admin'
                elif int(id) >= 2 and int(id) <= 10:
                    role = 'special_authorities'
                elif int(id) >= 11 and int(id) <= 30:
                    role = 'regular_worker'
                else:
                    self.label3 = tk.Label(self, text="Invalid ID number")
                    self.label3.pack()
                    return
                if role == "admin":
                    self.destroy()
                    self.main_program = MainProgramAdmin()
                elif role == "special_authorities":
                    self.destroy()
                    self.main_program = MainProgramSpecialAuthorities()
                elif role == "regular_worker":
                    self.destroy()
                    self.main_program = MainProgramRegularWorker()


class MainProgramAdmin(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.title("Glavni program")
        self.geometry("1920x1080")
        self.button1 = tk.Button(self, text="Option 1", command=lambda:CrudeBolnica.CrudeBolnica())
        self.button1.pack()
        self.button2 = tk.Button(self, text="Option 2", command=self.option2)
        self.button2.pack()
        self.button3 = tk.Button(self, text="Option 3", command=self.option3)
        self.button3.pack()

    def option1(self):
        pass

    def option2(self):
        pass

    def option3(self):
        pass


class MainProgramUser(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.title("Main Program (User)")
        self.geometry("300x200")
        self.button1 = tk.Button(self, text="Option 4", command=self.option4)
        self.button1.pack()
        self.button2 = tk.Button(self, text="Option 5", command=self.option5)
        self.button2.pack()

    def option4(self):
        pass

    def option5(self):
        pass

if __name__ == "__main__":
    app = Login()
    app.mainloop()